#include<iostream>
using namespace std;
void print_Pattern(int n, int i){
    if (n < 0)
        return;
     
    if (i <= n){
        cout<<n<<" ";
        print_Pattern(n, i +1);
    }   
     
    else{
        cout<<endl;
        print_Pattern(n-1, 1);
    }
}
 
int main(){
	int n;
    cout<<"Enter your input:"<<endl;
    cin>>n;
    cout<<endl<<endl;
    print_Pattern(n, 1);
    
    return 0;   
}
