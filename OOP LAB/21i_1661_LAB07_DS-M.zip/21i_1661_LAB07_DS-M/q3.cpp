#include <iostream>
using namespace std;
 
void printn(int num){
    if (num == 0)
        return;
        
    cout << "*";
 
    printn(num - 1);
}
 
void pattern(int n, int i){
    if (n == 0)
        return;
        
    printn(i);
    cout << endl;
 
    pattern(n - 1, i - 1);
}
void pattern2(int n, int i){
    if (n == 0)
        return;
    printn(i);
    cout << endl;
 
    pattern2(n - 1, i + 1);
}

int main(){
	
    int n = 5;
    pattern(n, 5);
    pattern2(n, 1);
    return 0;
}
