#include <iostream>
using namespace std;
int print_Row(int alphabet, int num){

	if (num == 0)
		return alphabet;
	cout<<(char)(alphabet + 64)<<" ";

	print_Row(alphabet + 1, num - 1);
}
void pattern(int input, int count, int num){

	if (input == 0)
		return;
	count = print_Row(count, num);
	cout << endl;

	pattern(input - 1, count, num + 1);
}

int main(){
	
	int Num;
	cout<<"Input number of lines : ";
	cin>>Num;
	pattern(Num, 1, 1);
}

