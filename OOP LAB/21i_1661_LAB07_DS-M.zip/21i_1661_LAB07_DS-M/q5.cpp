#include<iostream>
using namespace std;
int recursiveSearch(int array[], int key, int size){
	
	size = size-1;
	if(size <0) 
		return -1;
	
	 else if(array[size]==key) 
		return 1;
		
	else 
		return recursiveSearch(array,key,size);	
}
int main() {
	cout<<"Enter The Size Of Array:   ";
	int size;
	cin>>size;
	int array[size], key, i, result;
	
	cout<<"Enter values of Array: "<<endl;
	for (int j=0;j<size;j++) {
		cout<<"Enter "<<j<<" Element : ";
		cin>>array[j];
	}
	
	//Your Array Is
	for (int a=0;a<size;a++) {
		cout<<"array[ "<<a<<" ]  = ";
		cout<<array[a]<<endl;
	}
	
	cout<<"Enter element to Search  in Array: "<<endl;
	cin>>key;
	
	result = recursiveSearch(array , key, size--);
	
	if(result == 1) 
		cout<<"Element was found in Array  ";
	
	 else 
		cout<<"Element WAS NOT Found in Array  ";
	
	return 0;
}
