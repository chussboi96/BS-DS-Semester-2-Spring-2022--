#include<iostream>
using namespace std;
void copy(char s1[], char s2[], int index){
    s2[index] = s1[index];

    if (s1[index] == '\0')
        return;

    copy(s1, s2, index + 1);
}
int main(){
    char s1[30], s2[30];
 
    cout<<"Enter string to copy: ";
    cin.getline(s1, 30);
    copy(s1, s2, 0);

    cout<<"The first string is: "<<s1<<endl;
    cout<<"The second copied string is: "<<s2<<endl;

    return 0;
}
 
