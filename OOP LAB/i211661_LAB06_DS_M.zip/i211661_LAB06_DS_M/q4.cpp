#include <iostream>
using namespace std;

void printPatternRow(int n){
    if (n < 1)
        return;
        
    cout<<"* ";
    printPatternRow(n-1);
}
 
void printPattern(int n){
  
    if (n < 1)
        return;

    printPatternRow(n);   
	cout<<endl;
    printPattern(n-1);
     
}
 
int main(){
    int n;
	cout<<"Enter number of rows you want to print: ";
	cin>>n;
    printPattern(n);
    return 0;
}
