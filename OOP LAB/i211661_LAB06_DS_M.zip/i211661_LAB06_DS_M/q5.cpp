#include <iostream>
using namespace std;
 
void blank_space(int space){
   
    if (space == 0)
        return;
    cout << " ";
 
    blank_space(space - 1);
}
 

void print_asterisk(int asterisk){
    
    if (asterisk == 0)
        return;
    cout<<"* ";
 
    print_asterisk(asterisk - 1);
}
 
void PrintPattern(int lines, int num){
  
    if (lines == 0)
        return;
    blank_space(lines - 1);
    print_asterisk(num - lines + 1);
    cout << endl;
 
    PrintPattern(lines - 1, num);
}
int main(){

    int lines;
	cout<<"Enter number of lines you want to print: ";
	cin>>lines;

    PrintPattern(lines, lines);

    return 0;
}
