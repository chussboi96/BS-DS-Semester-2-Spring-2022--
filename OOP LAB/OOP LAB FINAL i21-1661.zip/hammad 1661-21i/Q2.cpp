#pragma once
#include<iostream>
#include<string>
#include<fstream>
using namespace std;
class Admin
{
private:
	string name;
	float age;
	char gender;
public:
	void setname(string name)
	{
		this->name = name;
	}
	void setage(float age)
	{
		this->age = age;
	}
	void setGender(char G)
	{
		gender = G;
	}
	string getname()
	{
		return name;
	}
	float getage()
	{
		return age;
	}
	char getGender()
	{
		return gender;
	}
	void addDoctor()
	{
		ofstream write;
		write.open("DoctorData.txt", ios::app);
		cout << "How many doctors do you want to add:";
		int NODoc = 0;
		cin >> NODoc;
		Doctor* D = new Doctor[NODoc];
		for (int i = 0; i < NODoc; i++)
		{
			write << i;
			cout << "Enter Name of Doc: ";
			string name;
			D[i].setname(name);
			write << endl<<name;
			cout << "Enter Age:";
				int num;
			D[i].setage(num);
			write << endl << num;
			cout << "Enter Gender:";
				char G;
			D[i].setGender(G);
			write << endl << G;
			cout << "Enter Degree: ";
			string Deg;
			D[i].setDegree(Deg);
			write << endl << D;
			cout << "Experience in years:";
			float Exp;
			D[i].setExp(Exp);
			write << endl << Exp;
			write << endl;
		}
		cout << "Doctor Added Successfully!";
	}
	void viewData()
	{
		cout << "Enter Number of Doctor you want to see data of: ";
		int number;
		cin >> number;
		ifstream read;
		string storage;
		read.open("DoctorData.txt");
		while (getline(read, storage))
		{
			int store = 0;
			store = stoi(storage);
			if (store == number)
			{
				for (int i = 0; i < 5; i++)
				{
					getline(read, storage);
					cout << storage;
				}
				break;
			}
			else
				cout << "Doctor not found!";
		}
	}
};
class Doctor
{
private:
	string name;
	float age;
	char gender;
	string degree;
	float ExpInYears;
public:
	void setname(string name)
	{
		this->name = name;
	}
	void setage(float age)
	{
		this->age = age;
	}
	void setGender(char G)
	{
		gender = G;
	}
	void setDegree(string deg)
	{
		this->degree = deg;
	}
	float setExp(float E)
	{
		this->ExpInYears = E;
	}
	string getname()
	{
		return name;
	}
	float getage()
	{
		return age;
	}
	char getGender()
	{
		return gender;
	}
	string getdegree()
	{
		return degree;
	}
	float getExp()
	{
		return ExpInYears;
	}
	void addcredentials()
	{
		string store;
		ofstream write;
		write.open("DTimings.txt", ios::app);
		cout << "Enter Your Name:";
		cin >> store;
		write << store<<endl;
		cout << "Enter day for adding time:";
		cin >> store;
		write << store;
		write << "free time:" << endl;
		cout << "Enter free timings : ";
		cin >> store;
		write << store;
		write << endl<<"Schduled times:";
		cout << "Enter scheduled timings:";
		cin >> store;
		write << endl << store;
		cout << "Data Added successfully!";
	}
	void checktimings()
	{
		cout << "Your name please:";
		string store,store2;
		cin >> store;
		ifstream read;
		read.open("DTimings.txt");
		while (getline(read, store2))
		{
			if (store == store2)
			{
				for (int i = 0; i < 6; i++)
				{
					getline(read, store);
					cout << store;
				}
			}
		}
	}
};
class Patient
{
private:
	string name;
	float age;
	char gender;
	string TypeOfDisease;
public:
	void setname(string name)
	{
		this->name = name;
	}
	void setage(float age)
	{
		this->age = age;
	}
	void setGender(char G)
	{
		gender = G;
	}
	void setdisease(string D)
	{
		this->TypeOfDisease = D;
	}
	string getname()
	{
		return name;
	}
	float getage()
	{
		return age;
	}
	char getGender()
	{
		return gender;
	}
	string getdisease()
	{
		return TypeOfDisease;
	}
};
int main()
{

}
