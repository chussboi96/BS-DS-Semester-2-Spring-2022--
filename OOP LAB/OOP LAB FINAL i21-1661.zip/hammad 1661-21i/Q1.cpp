#include <iostream>
using namespace std;
bool Quadruples(int array[], int x, int target_sum, int counter){
   
    if (target_sum == 0 && counter == 4) {
        return true;
    }
 
    if (counter > 4 || x == 0) {
        return false;
    }

    return Quadruples(array, x - 1, target_sum - array[x - 1], counter + 1) ||  Quadruples(array, x - 1, target_sum, counter);
}
 
int main()
{
    int array[] = { 2, 7, 4, 0, 9, 5, 1, 3 };
    int target_sum;
 	cout<<"Enter target sum: "<<endl;
	cin>>target_sum;
	cout<<"The target sum is "<<target_sum<<" ";
    int x = sizeof(array) / sizeof(array[0]);
 
    Quadruples(array, x, target_sum, 0) ? cout << "Quadruplet exists":
                                cout << "Quadruplet Doesn't Exist";
 
    return 0;
}


