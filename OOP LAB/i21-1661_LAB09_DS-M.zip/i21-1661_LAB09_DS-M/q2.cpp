#include <iostream>
#include <string.h>
using namespace std;
class Right_rectangular_prism{
private:
	int length;
	int height;
	int width;
public:
	Right_rectangular_prism(){
	length=0;
	width= 0;
	height= 0;
	cout<<"default constructor called."<<endl;
}
	Right_rectangular_prism(int length, int height, int width){
	length= 2;
	height= 5;
	width= 10;
	cout<<"Para constructor called."<<endl;
}
	int calculate_area(){
	int area= 2*( (width*length) * (height*length) * (height*width) );
	return area;
}
	~Right_rectangular_prism(){
	cout<<"Destructor called..."<<endl;
}
};
int main(){
	Right_rectangular_prism box1(10, 10, 10);
	
	cout<<box1.calculate_area();

return 0;
}


