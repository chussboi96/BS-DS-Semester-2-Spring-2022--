#include <iostream>
#include <string.h>
using namespace std;
class Person_bio{
private:
	int age;
	string firstName;
	string lastName;
	int IDcard_no;
	string address;
public:
	Person_bio(){
	age= 96;
	firstName= "Hello";
	lastName = "World";
	IDcard_no = 1661;
	address = "Faisalabad";
	cout<<"default constructor called."<<endl;
}
	void setAge(int personAge){
	age= personAge;
}
	void setfirstName(string personFirstName){
	firstName = personFirstName;
}
	void setlastName(string personLastName){
	lastName = personLastName;
}
	void setIDcard_no(int personID_no){
	IDcard_no = personID_no;
}
	void setAddress(string personAddress){
	address= personAddress;
}
	int getAge(){
	return age;
}
	string getFirstName(){
	return firstName;
}
	string getlastName(){
	return lastName;
}
	int getIDcard_no(){
	return IDcard_no;
}
	string getAddress(){
	return address;
}
string tostring(){
string a=to_string(age);
string i=to_string(IDcard_no);
string con_s=firstName+" "+lastName+"/0"+a+"-"+i+"-"+address;
cout<<endl;
return con_s;
}
	~Person_bio(){
	cout<<"Destructor called..."<<endl;

}
};
int main(){
	Person_bio student;

	cout<<student.tostring();

return 0;
}
