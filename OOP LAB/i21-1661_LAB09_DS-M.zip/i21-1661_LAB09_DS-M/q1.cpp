#include <iostream>
#include <string.h>
using namespace std;
class student{
private:
	string name;
	int roll_no;
	char section;
	float CGPA;
public:
	student(){
	name = "Aimal khan";
	roll_no= 1701;
	section = 'M';
	CGPA= 4.1;
	cout<<"default constructor called."<<endl;
}
	void setName(string studentName){
	name=studentName;
}
	void setRollNumber(int rollNumber){
	roll_no= rollNumber;
}
	void setSection(char studentSection){
	section = studentSection;
}
	void setGPA(float studentGPA){
	CGPA = studentGPA;
}
	string getName(){
	return name;
}
	int getRollNumber(){
	return roll_no;
}
	char getSection(){
	return section;
}
	float getCGPA(){
	return CGPA;
}
	~student(){
	cout<<"Destructor called..."<<endl;
}
};
int main(){
	student x1;

	x1.setName("Hammad");
	x1.setRollNumber(1661);
	x1.setSection('N');
	x1.setGPA(5.0);

	cout<<x1.getName()<<endl;
	cout<<x1.getRollNumber()<<endl;
	cout<<x1.getSection()<<endl;
	cout<<x1.getCGPA()<<endl;


return 0;
}





/*	beautiful(int xvalue, double yvalue){
	cout<<"Para constructor called."<<endl;
	x= xvalue;
	y= yvalue;
}	*/
