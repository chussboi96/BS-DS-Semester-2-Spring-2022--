#ifndef PERMANENTEMPLOYEE_H
#define PERMANENTEMPLOYEE_H
#include <string>
#include "Employee.h"

using namespace std;

class PermanentEmployee : Employee
{
private:
    /* data */
    int hourlyIncome;
public:
    PermanentEmployee(/* args */);
    PermanentEmployee(int a, string b, int hr);
    void calculate_the_income();
};


#endif