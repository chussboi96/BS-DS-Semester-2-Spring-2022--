#ifndef BANKACCOUNT_H
#define BANKACCOUNT_H
using namespace std;

class BankAccount
{
private:
    int accountID;
    int balance;
    /* data */
public:
    BankAccount(/* args */);
    BankAccount(int a, int b);
    void setaccountID(int a);
    void setbalance(int a);

    int getaccountID();
    int getbalance();

    void balanceInquiry();
};

#endif