#ifndef EMPLOYEE_H
#define EMPLOYEE_H
#include <string>

using namespace std;

class Employee
{
private:
    /* data */
    string name;
    int empID;
public:
    Employee(/* args */);
    Employee(int a , string b);


};


#endif