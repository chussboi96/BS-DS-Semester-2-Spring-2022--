#ifndef CURRENTACCOUNT_H
#define CURRENTACCOUNT_H
#include "BankAccount.h"

using namespace std;

class CurrentAccount : public BankAccount
{
private:

    /* data */
public:
    CurrentAccount();
    CurrentAccount(int a, int b);
    void amountWithdrawn(int amount);
    void amountDeposit(int amount);
};

#endif