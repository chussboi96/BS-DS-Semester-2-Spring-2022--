#include <iostream>
#include "BankAccount.h"
using namespace std;

    BankAccount::BankAccount(/* args */)
    {
        accountID = 00000;
        balance = 5000;
    }
    BankAccount::BankAccount(int a, int b){
        accountID = a;
        balance = b;
    }
    
    void BankAccount::setaccountID(int a){
        accountID = a;

    }
    
    void BankAccount::setbalance(int a){
        balance = a;
    }

    int BankAccount::getaccountID(){
        return accountID;
    }
    
	int BankAccount::getbalance(){
        return balance;
    }
    
    void BankAccount::balanceInquiry(){
        cout<<"Account ID: "<<accountID<<endl;
        cout<<"Balance : "<<balance<<endl;
    }  
