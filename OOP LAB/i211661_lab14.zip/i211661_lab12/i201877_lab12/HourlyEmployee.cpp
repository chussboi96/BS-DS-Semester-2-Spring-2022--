#include <iostream>
#include <string>
#include "Employee.h"
#include "HourlyEmployee.h"
using namespace std;

    HourlyEmployee::HourlyEmployee(/* args */) : Employee(0,0){  
        hourlyIncome = 0;
    }
    
    HourlyEmployee::HourlyEmployee(int a, string b, int hi) : Employee(a,b){   
        cout<<"ID of hourly employee: "<<a<<endl;
        cout<<"Name of employee: "<<b<<endl;

        hourlyIncome = hi;
    }
    
    void HourlyEmployee::calculate_the_hourly_income(){   
        hourlyIncome = hourlyIncome * 150;
        cout<<"income of hourly employee: "<<hourlyIncome<<endl;

    }
