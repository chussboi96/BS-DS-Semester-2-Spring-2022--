#include <iostream>
#include "Employee.h"
#include "PermanentEmployee.h"

using namespace std;

    PermanentEmployee::PermanentEmployee(/* args */) : Employee(0,0){

    }
    
    PermanentEmployee::PermanentEmployee(int a, string b, int hr) : Employee(a,b){   
        cout<<"ID of hourly employee: "<<a<<endl;
        cout<<"Name of employee: "<<b<<endl;

        hourlyIncome = hr;
    }

    void PermanentEmployee::calculate_the_income(){
        hourlyIncome = hourlyIncome + 240;
        cout<<"income of permanent employee: "<<hourlyIncome<<endl;
    }
