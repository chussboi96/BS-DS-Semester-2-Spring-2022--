#ifndef SAVINGSACCOUNT_H
#define SAVINGSACCOUNT_H
#include "BankAccount.h"

using namespace std;

class SavingsAccount : public BankAccount
{
private:

    /* data */
public:
    SavingsAccount();
    SavingsAccount(int a, int b);
    void amountWithdrawn(int amount);
    void amountDeposit(int amount);
};

#endif