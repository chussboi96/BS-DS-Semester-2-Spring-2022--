#include <iostream>
#include "BankAccount.h"
#include "SavingsAccount.h"
using namespace std;

    SavingsAccount::SavingsAccount(){
        setbalance(5000);
        setaccountID(0000);
    }
    
    SavingsAccount::SavingsAccount(int a, int b){
        setbalance(a);
        setaccountID(b);
    }
    
    void SavingsAccount::amountWithdrawn(int amount){
          if (getbalance() > 10000)
        setbalance(getbalance() - amount);
        else
            cout<<"Account should have greater than rs10000";
    }
    
    void SavingsAccount::amountDeposit(int amount){
         setbalance(getbalance() + amount);
    }
