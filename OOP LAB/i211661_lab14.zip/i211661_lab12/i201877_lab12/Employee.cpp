#include <iostream>
#include "Employee.h"
using namespace std;

    Employee::Employee(/* args */){
        empID = 0;
        name = "lala";
    }
    
    Employee::Employee(int a , string b){
        empID = a;
        name = b;
    }
