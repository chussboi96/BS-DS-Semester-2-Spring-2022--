#ifndef HOURLYEMPLOYEE_H
#define HOURLYEMPLOYEE_H
#include <string>
#include "Employee.h"

using namespace std;

class HourlyEmployee : public Employee
{
private:
    int hourlyIncome;
    /* data */
public:
    HourlyEmployee(/* args */);
    HourlyEmployee(int a, string b, int hi);
    void calculate_the_hourly_income();

};


#endif