#include <iostream>
#include "Employee.cpp"
#include "PermanentEmployee.cpp"
#include "HourlyEmployee.cpp"

using namespace std;

int main(int argc, char const *argv[]){
    HourlyEmployee hr( 1877, "Bilal", 450000);

    PermanentEmployee pr( 1879, "Juin", 700000);

    hr.calculate_the_hourly_income();
    pr.calculate_the_income();

    return 0;
}
