#include <iostream>
#include "CurrentAccount.cpp"
#include "SavingsAccount.cpp"
#include "BankAccount.cpp"

using namespace std;

int main(int argc, char const *argv[]){
    CurrentAccount ca(234233,12424);
    SavingsAccount sa(45000,123131);

    ca.amountWithdrawn(0);
    sa.amountDeposit(1000);

    sa.balanceInquiry();

    return 0;
}
