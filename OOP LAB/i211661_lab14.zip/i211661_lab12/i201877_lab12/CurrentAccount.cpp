#include <iostream>
#include "BankAccount.h"
#include "CurrentAccount.h"
using namespace std;

    CurrentAccount::CurrentAccount(){
        setbalance(5000);
        setaccountID(0000);
    }
    
    CurrentAccount::CurrentAccount(int a, int b){
        setbalance(a);
        setaccountID(b);
    }
    
    void CurrentAccount::amountWithdrawn(int amount){   
         if (getbalance() > 5000)
         setbalance(getbalance() - amount);
    else
       cout<<"Account should have greater than rs5000";
    }
    
    void CurrentAccount::amountDeposit(int amount){
         setbalance(getbalance() + amount);
    }
