#include <iostream>
using namespace std;

char *$vowels( char *string, int size){
	for(int i= 0; i < size; i++){
		if(string[i] == 'a' || string[i] == 'e' || string[i] == 'i' || string[i] == 'o' || string[i] == 'u' ||string[i] == 'A' ||
			string[i] == 'E' || string[i] == 'I' || string[i] == 'O' ||  string[i] == 'U')
			
				string[i] = '$';
	}
  	
  	
return string;
}

