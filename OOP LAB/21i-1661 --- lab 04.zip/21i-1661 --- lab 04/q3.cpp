#include <iostream>
#include <time>
using namespace std;

void three_D(int ***&arr, int size, int rows, int column)
{
		srand(time(NULL));
		for(int i= 0; i<size; i++){
			arr[i]= new int*[rows];
				for(int j= 0; j<rows; j++)
				arr[i][j] = new int [column];
		}
		for(int i= 0; i<size; i++){
		
				for(int j= 0; j<rows; j++){
					
					for(int k= 0; k<column; k++)
					arr[i][j] = rand() % 50;
				}
		}
		cout<<"1 page";
		
		for(int i= 0; i<size; i++){
		
				for(int j= 0; j<rows; j++){
					
					for(int k= 0; k<column ; k++){
					cout<<arr[i][j]<<" ";
				}	cout<<endl;
				}
				cout<<endl<<i+2<<"Page"<<endl;
		}
		
		for(int i= 0; i<size; i++){
			
				for(int j= 0; j<rows; j++){
				delete []arr[i][j];
				}
				delete []arr[i];
		}
			delete []arr;
}

int main(){
	int p, c , r;
	cout<<"Enter pages: ";
	cin>>p
	cout<<"Enter columns: ";
	cin>>c;
	cout<<"Enter rows: ";
	cin>>r;
	
	int*** array = new int **[s];
	three_D(array, p, r, c);
	
	
	
	
	
	
	
	
	
	
	
}
